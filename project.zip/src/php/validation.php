<html>
    please check your infi

    name:<?php $name ?>
    roll number:<?php $rollnumber ?>
    class:<?php $class ?>
    year: <?php $class ?>

</html>