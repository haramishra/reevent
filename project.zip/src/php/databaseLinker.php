<?php

    $dbServer = "sql301.epizy.com";
    $dbUsername = "epiz_23575771	";
    $dbPassword = "5BQpNw15I3xWO5";
    $dbName = "epiz_23575771_re_event";
    //database connection
    $conn = mysqli_connect("$dbServer", "$dbUsername", "$dbPassword", "$dbName");
    //check for errors
    if (!$conn) {
        die('Connection Error (' . mysqli_connect_errno() . ')  ' . mysqli_connect_error());
    }
